/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scriptcalcu;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author Evelyn
 */
public class ScriptCalcu extends JFrame{
    JTextField field = new JTextField();
    JButton satu = new JButton("1");
    JButton dua = new JButton("2");
    JButton tiga = new JButton("3");
    JButton empat = new JButton("4");
    JButton lima = new JButton("5");
    JButton enam = new JButton("6");
    JButton tujuh = new JButton("7");
    JButton delapan = new JButton("8");
    JButton sembilan = new JButton("9");
    JButton nol = new JButton("0");
    JButton titik = new JButton(".");
    JButton clear = new JButton("CE");
public ScriptCalcu() {
        super("Kalkulator");
    setSize(300, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pane = new JPanel();
        setLayout(new BorderLayout());
            add(field, BorderLayout.NORTH);
 GridLayout angka = new GridLayout(4,3,10,10);
 pane.setLayout(angka);
 pane.add(sembilan); pane.add(delapan); pane.add(tujuh);
 pane.add(enam); pane.add(lima); pane.add(empat);
 pane.add(tiga); pane.add(dua); pane.add(satu);
 pane.add(nol); pane.add(titik); pane.add(clear);
add(pane);
setVisible(true);
}   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ScriptCalcu frame = new ScriptCalcu();
    }
    
}
